int LED1=2;
int tombol1=4;
bool statusTombol;
bool statusLED;
bool terakhirnyala;
void setup() {
  Serial.begin(115200);
  pinMode(LED1, OUTPUT);
  pinMode(tombol1, INPUT_PULLUP);
}

void loop() {
  statusTombol = digitalRead(tombol1);
  if(statusTombol == HIGH && terakhirnyala == LOW){
  statusLED = !statusLED;
  digitalWrite(LED1, statusLED);
  }
  terakhirnyala = statusTombol;
  delay(200);

}

